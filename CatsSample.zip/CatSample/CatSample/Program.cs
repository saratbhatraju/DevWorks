﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace CatsSample
{
    class Program
    {
        static void Main(string[] args)
        {
            GetJSONData().Wait();
        }

        /// <summary>
        /// To consume and retrive the JSON data
        /// </summary>
        
        static async Task GetJSONData()
        {
            string uri = ConfigurationManager.AppSettings["uri"];
            using (var client = new HttpClient())
            {
                Uri geturi = new Uri(uri);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    HttpResponseMessage response = await client.GetAsync(geturi);
                    response.EnsureSuccessStatusCode();

                    string jsonResponse = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("\n" + "JSON Data:");
                    Console.WriteLine(jsonResponse+ "\n");

                    //Deserializing the JSON object
                    List<Owner> ownersList = JsonConvert.DeserializeObject<List<Owner>>(jsonResponse);

                    //Query to get the list of all the cats in alphabetical order and group by gender of their owner
                    var results = from owner in ownersList where owner.Pets != null
                                  from y in owner.Pets where y.Type == "Cat"
                                  orderby y.Name ascending group y.Name by owner.Gender into data
                                  select new { data.Key, cats = data.ToList() };

                    //Output the list of all the cats
                    foreach (var result in results)
                    {
                        Console.WriteLine("\n" + result.Key+ ":" + "\n");
                        foreach (var catName in result.cats)
                        {
                            Console.WriteLine(catName);
                        }
                    }
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }        
    }

    /// <summary>
    /// Class to represent the owner
    /// </summary>
    public class Owner
    {
        public string Name { get; set; }

        public string Gender { get; set; }

        public int Age { get; set; }

        public List<Pet> Pets { get; set; }
    }

    /// <summary>
    /// Class to represent the Pet
    /// </summary>
    public class Pet
    {
        public string Name { get; set; }

        public string Type { get; set; }
    }
}
